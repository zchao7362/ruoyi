<?php
if (empty($_POST)) $_POST = $_GET;  //如果为GET方式访问

$payid = $_POST['payid'];
$amount = $_POST['amount'];//金额
//$value = 0.01;
$actorid = $_POST['actorid'];
$serverid = $_POST['qu'];//分区ID
$rolename = $_POST['actorname'];//角色名称
$accounts = $_POST["username"];//登录账号
$account =  $serverid."_".$actorid."_".$rolename."_".$payid."_".$accounts;

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>游戏赞助</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta content="telephone=no" name="format-detection">
	<!--引入阿里字体图标-->
	<link rel="stylesheet" type="text/css" href="static/css/iconfont.css" />
	<!--引入jquery-->
	<script src="static/js/jquery.min.js" charset="utf-8"></script>
	<!--引入jquery-weui框架-->
	<link rel="stylesheet" href="static/weui/css/weui.min.css">
	<link rel="stylesheet" href="static/weui/css/jquery-weui.min.css">
	<script src="static/weui/js/jquery-weui.min.js" charset="utf-8"></script>
	<link rel="stylesheet" href="static/css/pay.css" type="text/css">
</head>
<body class="center">
	<!--头部  star-->
	<header>
		<div class="title-box">
			<a href="#" onclick="window.close();" class="title-left"><i class="iconfont" style="font-size:16px;">&#xe635;</i>返回游戏</a>
			<a class="title-center"></a>
			<a href="#" onclick="window.close();" class="title-right"><i class="iconfont" style="font-size:16px;">&#xe613;</i></a>
		</div>
	</header>
	<!--头部 end-->
    <form action="Submit.php" method="post">
        <div class="weui-pay">
            <h1 class="weui-payselect-title">充值金额</h1>
            <p class="weui-pay-num">￥<?php echo $amount?>.00</p>
            <p class="weui-pay-info"><label class="label f-red b-red f16">充值角色 → 【<?php echo $rolename?>】</label></p>
            <!--支付 star-->
			<div class="pay-box">
				<div class="pay-box-cell">
					<li>
					<label>
					<img src="static/images/pay-zfb.jpg">
					<input name="type" value="alipaywap" type="radio" checked='true'>
					<span></span>
					</label> 
					</li>
				</div>
			</div>
			<!--支付 end-->
            <div class="pay-div">
                <input type='hidden' name='amount' value ='<?php echo $amount;?>'/>
                <input type='hidden' name='rolename' value ='<?php echo $rolename;?>'/>
                <input type='hidden' name='account' value ='<?php echo $account;?>'/>
                <button type="submit" class="weui-btn weui-btn_primary">立即支付</button>
				<button type="button" class="weui-btn weui-btn_default"><span class="am-icon-qq"></span>客服QQ：82248126</button>
            </div>
        </div>
    </form>
</body>
</html>