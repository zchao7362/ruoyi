<?php
/**
 *   ┏┛ ┻━━━━━┛ ┻┓
 *  ┃　　　　　　┃
 *  ┃　美　   廉　┃
 *  ┃　　　┻　　 ┃
 *  ┗━┓　　　┏━━━┛
 *    ┃　　　┃   神兽保佑
 *    ┃　　　┃   代码无BUG！
 *    ┃　　　┗━━━━━━━━━┓
 *    ┃　　　　　　　  ┣┓
 *    ┃　　　　       ┏┛
 *    ┗━┓ ┓ ┏━━━┳ ┓ ┏━┛
 *      ┗━┻━┛   ┗━┻━┛
 * QQ:513556415 zf.mlzf8.com
 */
ini_set("error_reporting","E_ALL & ~E_NOTICE");
//修改商户密钥-商户后台-①教程下载-通讯秘钥里面
$apikey = '95ad4df24fec408b590c10c4dc7fb827';
function chongzhi($data)
{
	//数据库
$db_host='127.0.0.1';
$db_username='root';//数据库帐号
$db_password='123456';//数据库密码，不知道的可以看GM后台或者咨询架设技术
//===============游戏分区=================================
$db = array(
	1=>"actor_s1", //一区 有些服使用的是 actor_s1 或者actor
	2=>"actor_s2", //二区
	3=>"actor_s3", //三区
	4=>"actor_s4", //四区
	5=>"actor_s5", //五区
	6=>"actor_s6", //六区
	7=>"actor_s7", //七区
	8=>"actor_s8", //八区
	9=>"actor_s9", //九区	
	10=>"actor_s10", //十区	
	11=>"actor_s11", //十一区	
	12=>"actor_s12", //十二区
);
	
    //游戏充值代码，以下不需要动
    $account = $data['account'];
    $accounta = explode("_",$account);

    $qu = $accounta[0];
    $actorid = $accounta[1];
    $payid = $accounta[3];
    $acountname = $accounta[4];//充值账号
    
    $money = $data['money'];
	$gold = $data['game_amount'];
    $con = @mysql_connect($db_host,$db_username,$db_password)or die("数据库链接失败!");
    //mysql_query("set names 'utf8'");
    if($db[$qu]){
        $dbgame = $db[$qu];
    }else{
        $dbgame = $db[1];
    }
    mysql_select_db($dbgame,$con);
    $result=mysql_query("SELECT accountname,actorid FROM actors WHERE actorid = '$actorid'");//SQL语句
   
    if($result&&mysql_num_rows($result)>0){
        $row = mysql_fetch_array($result);
        $accountname=$row[0];
        $actorid=$row[1];
        
        if ($payid>99) {
             mysql_query("insert into feecallback(serverid,openid,itemid,actor_id) values ('$qu','$acountname','$payid',$actorid)");
        }else {
             mysql_query("insert into feecallback(serverid,openid,itemid,actor_id) values ('$qu','$acountname','$gold',$actorid)");
        }
       
        
        mysql_close($con);
        //游戏充值代码
        echo "success";
    }else{
        echo "该帐号在".$dbgame."还没有角色ID".$actorid."呢";
        mysql_close($con);
        exit;
        die();
    }
}

//下面代码基本不需要修改
$data = json_decode(file_get_contents("php://input"), true);
$sign = $data['sign'];
unset($data['sign']);
ksort($data);
// $signStr = urldecode(http_build_query($data)).''.$key;
// echo $signStr."-1-";
$mysign = sign($data,$apikey);
//echo $mysign."-2-";;
if($mysign==$sign){
	$data['account']=$data['game_user_id'];
	$data['money']=$data['amount'];
    chongzhi($data);
}else{
    echo "sign error";
}

function sign($data,$key) {
    ksort($data);
    $sign = md5(urldecode(http_build_query($data)).''.$key);
    return $sign;
}