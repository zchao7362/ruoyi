<?php
/*
 * 迅速支付 https://www.m1m1.cn
 * Date: 2018/08/25
 * Time: 19:58
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究接口使用，只是提供一个参考，最终解释权归迅速支付开发工作室所有。
 * 严禁一切钓鱼、色情、赌博、私彩及违反国家法律法规等使用。
 * 注意：
 * UTF-8编码不要在记事本下编辑，否则会出现一些奇葩的问题，正确方法应在开发工具里打开编辑
 */
error_reporting(E_ALL ^ E_DEPRECATED);
header("Content-type: text/html; charset=utf-8");
/////////////////需要修改的参数/////////////////
//商户编号
$parter = '800809420';
//商户密钥
$key = '62106914e34f8795b6587c1a6598c726';
//分区充值连接（修改为自己的分区链接，迅速支付平台上面只需要创建一个分区即可）
$payurl = 'http://pay.yjw.ink/outside/pay/alipay';

$appidKey = "5cf4dc0dc8414bc6b4f0be225dbd64bc";
$tokenKey = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjg4OCwiZXhwaXJlX3RpbWUiOjE2ODc5MjMwNzY2Njl9.6b60vSTaeb8FScO8uF1KzhbR6UjBnfcUlm7xbNqRluw";
$timestamps = time();
$callbackUrl = "http://yjw.ink/pay/pay.php";



//数据库配置
define('HOST','127.0.0.1');
define('PORT',3306);
define('USER','root');
define('PASS','123456');
//======================游戏分区=========================//
$db = array(
	1=>"actor_s1", //一区 有些服使用的是 actor_s1 或者actor
	2=>"actor_s2", //二区
	3=>"actor_s3", //三区
	4=>"actor_s4", //四区
	5=>"actor_s5", //五区
	6=>"actor_s6", //六区
	7=>"actor_s7", //七区
	8=>"actor_s8", //八区
	9=>"actor_s9", //九区	
	10=>"actor_s10", //十区	
	11=>"actor_s11", //十一区	
	12=>"actor_s12", //十二区
);
?>