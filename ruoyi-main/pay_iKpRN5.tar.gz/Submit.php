<!DOCTYPE html>
<?php
date_default_timezone_set('Asia/Shanghai');
header("Content-type: text/html; charset=utf-8");

//引入配置文件
require("config.php");

//接收参数
$type=$_POST['type'];//支付方式
$orderid =date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);//商户订单号
$amount = $_POST['amount'];//订单金额
$account = $_POST['account'];//充值帐号
$regionName = $_POST['rolename'];//角色名称



//准备加密字符串
//$md5String="parter={$parter}&type={$type}&value={$value}&orderid={$orderid}&account={$account}$key";
$sginStr = $appidKey.$account.$callbackUrl.$amount.$timestamps.$tokenKey;
//md5加密
$sign = strtoupper(md5($sginStr));
//$sign=md5(urlencode($md5String));
?>

<html>
<head>
    <title>连接网关中...</title>
</head>
<body>
    <form action="<?=$payurl?>" method="post" >
		<input type="hidden" class="form-control" id="orderNo" name="orderNo" value="<?php echo $orderid;?>"  />
		<input type="hidden" class="form-control" id="amount" name="amount" value="<?php echo $amount;?>"  />
		<input type="hidden" class="form-control" id="accountName" name="accountName" value="<?php echo $regionName;?>"  />
		<input type="hidden" class="form-control" id="remark" name="remark" value="<?php echo $remark;?>"   />
		<input type="hidden" class="form-control" id="appid" name="appid" value="<?php echo $appidKey;?>"   />
		<input type="hidden" class="form-control" id="merchantOrderNo" name="merchantOrderNo" value="<?php echo $account;?>" />
		<input type="hidden" class="form-control" id="callbackUrl" name="callbackUrl" value="<?php echo $callbackUrl;?>"  / >
		<input type="hidden" class="form-control" id="yjAmount" name="yjAmount" value="<?php echo $yjAmount;?>" />
		<input type="hidden" class="form-control" id="method" name="method" value="10"  />
		<input type="hidden" class="form-control" id="timestamps" name="timestamps" value="<?php echo $timestamps;?>"  />
		<input type="hidden" class="form-control" id="sign" name="sign" value="<?php echo $sign;?>"  />
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>