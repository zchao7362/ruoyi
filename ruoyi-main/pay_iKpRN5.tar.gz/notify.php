<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");
header("Content-type: text/html; charset=utf-8");

//引入配置文件
require("config.php");

//接收参数
$orderid=$_GET['orderid'];//商户订单号
$opstate=$_GET['opstate']; //0表示支付成功
$ovalue=$_GET['ovalue'];//订单金额
$scale=$_GET['scale'];//充值比例
$account=urldecode($_GET['account']);//充值账户
$sysorderid=$_GET['sysorderid'];//迅速支付订单号
$systime=$_GET['systime'];//迅速支付处理完时间
$attach=$_GET['attach'];//备注消息
$sign=$_GET['sign'];//加密密文

//准备加密字符串
$signStr="orderid={$orderid}&opstate={$opstate}&ovalue={$ovalue}$key";
//md5加密
$mysign=md5(urlencode($signStr));

if($mysign==$sign){
	//验证成功，执行充值操作。
    $accounta = explode("_",$account);//分割账号
    $qu = $accounta[0];//分区ID
    $actorid = $accounta[1];//
    $payid = $accounta[3];
	$acountname = $accounta[4];//充值账号

	$gold=$ovalue*$scale;//元宝=充值金额*充值比例
	$con = @mysql_connect(HOST,USER,PASS,PORT) or die("数据库链接失败!");
	mysql_query("set names 'utf8'");
    if($db[$qu]){
        $dbgame = $db[$qu];
    }else{
        $dbgame = $db[1];
    }
    mysql_select_db($dbgame,$con);
    $result=mysql_query("SELECT accountname,actorid FROM actors WHERE actorid = '$actorid'");//SQL语句
    if($result&&mysql_num_rows($result)>0){
        $row = mysql_fetch_array($result);
        $accountname=$row[0];
        $actorid=$row[1];
        
        if ($payid>99) {
             mysql_query("insert into feecallback(serverid,openid,itemid,actor_id) values ('$qu','$acountname','$payid',$actorid)");
        }else {
             mysql_query("insert into feecallback(serverid,openid,itemid,actor_id) values ('$qu','$acountname','$gold',$actorid)");
        }
       
        
        mysql_close($con);
        //游戏充值代码
        echo "success";
    }else{
        echo "该帐号在".$dbgame."还没有角色ID".$actorid."呢";
        mysql_close($con);
        exit;
        die();
    }
}else{
	//验证失败
    echo "sign error";
}